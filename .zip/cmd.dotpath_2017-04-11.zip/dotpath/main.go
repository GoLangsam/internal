package main

import (
	"flag"
	"fmt"

	"container/ccsafe/dotpath"
)

func main() {
	flag.Parse()

	ds := dotpath.FilePathS(flag.Args()...)
	fmt.Println("===============================================================================")
	for _, dp := range ds {
		dp.Print()
		fmt.Println("-------------------------------------------------------------------------------")
	}
}
