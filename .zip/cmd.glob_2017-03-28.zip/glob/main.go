package main

import (
	"flag"
	"fmt"
	"path/filepath"
)

func main() {
	flag.Parse()

	for _, arg := range flag.Args() {
		matches, err := filepath.Glob(arg)
		if err != nil {
			fmt.Println("Error:", err.Error())
		} else {
			for _, match := range matches {
				fmt.Println(match)
			}
		}
	}
}
