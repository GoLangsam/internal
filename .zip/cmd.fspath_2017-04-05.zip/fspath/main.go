package main

import (
	"flag"
	"fmt"

	"cmd/dotgo/fsa"
	"container/ccsafe/dotpath"
)

func analyse(pathS ...*dotpath.DotPath) *fsa.Analysis {

	a := fsa.Analyse(pathS...)

	dc := PipeFsInfoFunc(ChanFsInfo(a.FsFoldS...), FsInfoSPrintFunc("DirS"))
	fc := PipeFsInfoFunc(ChanFsInfo(a.FsFileS...), FsInfoSPrintFunc("FilS"))
	rc := PipeFsInfoFunc(ChanFsInfo(a.RecurseS...), FsInfoSPrintFunc("Into"))

	// accumulators - one by one
	DirS := PipeFsInfoS(dc)
	_ = <-DirS
	FilS := PipeFsInfoS(fc)
	_ = <-FilS
	Read := PipeFsInfoS(rc)
	_ = <-Read

	return a
}

func main() {
	flag.Parse()
	ds := dotpath.FilePathS(flag.Args()...)
	for _, dp := range ds {
		fmt.Println("====================================")
		fmt.Println("Got:\t", dp.String())
		rp := dp.RecursePathS()
		fmt.Println("=> Path:\t", dp.Path())
		if len(rp) > 0 {
			fmt.Println("=> Name:\t", dp.PathName())
			fmt.Println("Recurse:\t", rp)
		}
		wd := dp.WaydownPathS()
		if len(wd) > 0 || dp.Path() != dp.PathBase() {
			fmt.Println("=> Base:\t", dp.PathBase())
			fmt.Println("WayDown:\t", dp.PathS())
		}
	}

	a := analyse(ds...)
	fmt.Println("BaseNameS:\t", a.BaseNameS)
	/*
		if err != nil {
			fmt.Println("Errors:\t", err.Error())
		}
	*/
}
