﻿// Copyright 2017 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

// DO NOT EDIT.
// Generate with: go run gen.go

package main

import (
	"container/ccsafe/fsinfo"
)

// MakeFsInfoChan returns a new open channel
// (simply a 'chan *fsinfo.FsInfo' that is).
//
// Note: No 'FsInfo-producer' is launched here yet! (as is in all the other functions).
//
// This is useful to easily create corresponding variables such as
//
//	var myFsInfoPipelineStartsHere := MakeFsInfoChan()
//	// ... lot's of code to design and build Your favourite "myFsInfoWorkflowPipeline"
//	// ...
//	// ... *before* You start pouring data into it, e.g. simply via:
//	for drop := range water {
//		myFsInfoPipelineStartsHere <- drop
//	}
//	close(myFsInfoPipelineStartsHere)
//
// Hint: especially helpful, if Your piping library operates on some hidden (non-exported) type
// (or on a type imported from elsewhere - and You don't want/need or should(!) have to care.)
//
// Note: as always (except for PipeFsInfoBuffer) the channel is unbuffered.
//
func MakeFsInfoChan() (out chan *fsinfo.FsInfo) {
	cha := make(chan *fsinfo.FsInfo)
	return cha
}

// ChanFsInfo
func ChanFsInfo(inp ...*fsinfo.FsInfo) (out <-chan *fsinfo.FsInfo) {
	cha := make(chan *fsinfo.FsInfo)
	go func(out chan<- *fsinfo.FsInfo, inp ...*fsinfo.FsInfo) {
		defer close(out)
		for _, i := range inp {
			out <- i
		}
	}(cha, inp...)
	return cha
}

// ChanFsInfoSlice
func ChanFsInfoSlice(inp []*fsinfo.FsInfo) (out <-chan *fsinfo.FsInfo) {
	cha := make(chan *fsinfo.FsInfo)
	go func(out chan<- *fsinfo.FsInfo, inp []*fsinfo.FsInfo) {
		defer close(out)
		for _, i := range inp {
			out <- i
		}
	}(cha, inp)
	return cha
}

// JoinFsInfo
func JoinFsInfo(out chan<- *fsinfo.FsInfo, inp ...*fsinfo.FsInfo) {
	// cha := make(chan *fsinfo.FsInfo)	// no need
	go func(out chan<- *fsinfo.FsInfo, inp ...*fsinfo.FsInfo) {
		// defer close(out)	// no need
		for _, i := range inp {
			out <- i
		}
	}(out, inp...)
	// return cha	// no need
}

// JoinFsInfoSlice
func JoinFsInfoSlice(out chan<- *fsinfo.FsInfo, inp []*fsinfo.FsInfo) {
	// cha := make(chan *fsinfo.FsInfo)	// no need
	go func(out chan<- *fsinfo.FsInfo, inp []*fsinfo.FsInfo) {
		// defer close(out)	// no need
		for _, i := range inp {
			out <- i
		}
	}(out, inp)
	// return cha	// no need
}

// JoinFsInfoChan
func JoinFsInfoChan(out chan<- *fsinfo.FsInfo, inp <-chan *fsinfo.FsInfo) {
	// cha := make(chan *fsinfo.FsInfo)	// no need
	go func(out chan<- *fsinfo.FsInfo, inp <-chan *fsinfo.FsInfo) {
		// defer close(out)	// no need
		for i := range inp {
			out <- i
		}
	}(out, inp)
	// return cha	// no need
}

// DoneFsInfo
func DoneFsInfo(inp <-chan *fsinfo.FsInfo) (out <-chan struct{}) {
	cha := make(chan struct{})
	go func(inp <-chan *fsinfo.FsInfo, out chan<- struct{}) {
		defer close(out)
		for i := range inp {
			_ = i // Drain inp
		}
		out <- struct{}{}
	}(inp, cha)
	return cha
}

// DoneFsInfoFunc
func DoneFsInfoFunc(inp <-chan *fsinfo.FsInfo, act func(a *fsinfo.FsInfo)) (out <-chan struct{}) {
	cha := make(chan struct{})
	if act == nil {
		act = func(a *fsinfo.FsInfo) { return }
	}
	go func(inp <-chan *fsinfo.FsInfo, act func(a *fsinfo.FsInfo), out chan<- struct{}) {
		defer close(out)
		for i := range inp {
			act(i) // Apply action
		}
		out <- struct{}{}
	}(inp, act, cha)
	return cha
}

// PipeFsInfoBuffer
func PipeFsInfoBuffer(inp <-chan *fsinfo.FsInfo, cap int) (out <-chan *fsinfo.FsInfo) {
	cha := make(chan *fsinfo.FsInfo, cap)
	go func(inp <-chan *fsinfo.FsInfo, out chan<- *fsinfo.FsInfo) {
		defer close(out)
		for i := range inp {
			out <- i
		}
	}(inp, cha)
	return cha
}

// PipeFsInfoFunc
// Note: it 'could' be PipeFsInfoMap for functional people,
// but 'map' has a very different meaning in go lang.
func PipeFsInfoFunc(inp <-chan *fsinfo.FsInfo, act func(a *fsinfo.FsInfo) *fsinfo.FsInfo) (out <-chan *fsinfo.FsInfo) {
	cha := make(chan *fsinfo.FsInfo)
	if act == nil {
		act = func(a *fsinfo.FsInfo) *fsinfo.FsInfo { return a }
	}
	go func(inp <-chan *fsinfo.FsInfo, act func(a *fsinfo.FsInfo) *fsinfo.FsInfo, out chan<- *fsinfo.FsInfo) {
		defer close(out)
		for i := range inp {
			out <- act(i)
		}
	}(inp, act, cha)
	return cha
}

// Vocab:
// Demand  request call claim order
// Supply  Provide

// Request - aka Get
// Provide - aka Put

//   FsInfoRequester
type FsInfoDemander interface {
	RequestFsInfo() *fsinfo.FsInfo
}

//   FsInfoProvider
type FsInfoSupplier interface {
	ProvideFsInfo(*fsinfo.FsInfo)
}

// A Channel of type FsInfo satisfies this:
type FsInfoChaneler interface {
	FsInfoDemander
	FsInfoSupplier
}

type DemandFsInfo struct { // demand channel
	dat chan *fsinfo.FsInfo
	req chan struct{}
}

func NewDemandFsInfoChan() *DemandFsInfo {
	d := new(DemandFsInfo)
	d.dat = make(chan *fsinfo.FsInfo)
	d.req = make(chan struct{})
	return d
}

func (out *DemandFsInfo) ProvideFsInfo(dat *fsinfo.FsInfo) {
	<-out.req
	out.dat <- dat
}

func (inp *DemandFsInfo) RequestFsInfo() (dat *fsinfo.FsInfo) {
	inp.req <- struct{}{}
	return <-inp.dat
}

type SupplyFsInfo struct { // supply channel
	dat chan *fsinfo.FsInfo
	// req chan struct{}
}

func NewSupplyFsInfoChan() *SupplyFsInfo {
	d := new(SupplyFsInfo)
	d.dat = make(chan *fsinfo.FsInfo)
	// d.req = make(chan struct{})
	return d
}

func (out *SupplyFsInfo) Provide(dat *fsinfo.FsInfo) {
	// <-out.req
	out.dat <- dat
}

func (inp *SupplyFsInfo) Request() (dat *fsinfo.FsInfo) {
	// inp.req <- struct{}{}
	return <-inp.dat
}
