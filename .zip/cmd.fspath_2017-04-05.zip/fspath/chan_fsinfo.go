﻿package main

import (
	"fmt"
	"path/filepath"

	"container/ccsafe/fsinfo"
)

func FsInfoSPrintFunc(prefix string) func(fp *fsinfo.FsInfo) *fsinfo.FsInfo {
	return func(fp *fsinfo.FsInfo) *fsinfo.FsInfo {
		fmt.Println(prefix, fp.String())
		return fp
	}
}

func PipeFsInfoFork(inp <-chan *fsinfo.FsInfo) (out1, out2 <-chan *fsinfo.FsInfo) {
	cha1 := make(chan *fsinfo.FsInfo)
	cha2 := make(chan *fsinfo.FsInfo)
	go func() {
		defer close(cha1)
		defer close(cha2)
		for i := range inp {
			cha1 <- i
			cha2 <- i
		}
	}()
	return cha1, cha2
}

func PipeFsInfoGlob(
	inp <-chan *fsinfo.FsInfo,
	dirS, filS chan<- *fsinfo.FsInfo) (
	out <-chan struct{}) {
	cha := make(chan struct{})
	go func() {
		defer close(cha)
		for name := range inp {
			dS, fS, _ := fsinfo.MatchDisk(filepath.Join(name.String(), "*.tmpl"))
			for _, d := range dS {
				dirS <- d
			}
			for _, f := range fS {
				filS <- f
			}
		}
		cha <- struct{}{}
	}()
	return cha
}

// PipeFsInfoS returns a channel which will receice a slice of all elements
// received on inp channel, and will be closed thereafter.
// Thus, it behaves similar to a Done channel, just sending a full slice once,
// not just an (otherwise empty) event.
func PipeFsInfoS(inp <-chan *fsinfo.FsInfo) (out <-chan []*fsinfo.FsInfo) {
	cha := make(chan []*fsinfo.FsInfo)
	go func(inp <-chan *fsinfo.FsInfo, out chan<- []*fsinfo.FsInfo) {
		defer close(out)
		FsInfoS := []*fsinfo.FsInfo{}
		for i := range inp {
			FsInfoS = append(FsInfoS, i)
		}
		out <- FsInfoS
	}(inp, cha)
	return cha
}
